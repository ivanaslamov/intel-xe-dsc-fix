# Build the three Xe RPMs

The release contains the OGC kernel source tarball and this archive with the
patches, package specs, kernel configuration, and build script. Each numbered
directory records its Git revision in SOURCE-COMMIT.

Build on x86_64 Fedora or Bazzite with the exact OGC
`kernel-devel-7.3.3-ogc1.1.fc45.x86_64` build tree, GCC 16.2.1,
binutils 2.47, Git, Make, and the Fedora `rpm-build` package.
The matching OGC kernel packages are available from
[the OGC Fedora package image](https://github.com/OpenGamingCollective/kernel-packages/pkgs/container/kernel-packages-fedora)
tagged `7.3.3-ogc1.1-fc45`.

```bash
bash build.sh /absolute/path/to/ogc-linux-7.3.3-ogc1.tar.gz
```

Pass the extracted kernel-devel build directory as the second argument if it
lives outside the running kernel's module directory. The local build path and
package timestamps can produce different build IDs and hashes.
