#!/usr/bin/env bash
set -euo pipefail

source_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
release=7.3.3-ogc1.1.fc45.x86_64
archive=${1:?Pass the OGC source tarball path}
headers=${2:-/lib/modules/$release/build}
build=$(mktemp -d)
tool=${RPMBUILD:-rpmbuild}

printf 'Build directory: %s\n' "$build"
printf '8cadd5a5633be81982c48c9d8c8ca6ede034b322c018b99a66e5c0166aed3ce8  %s\n' "$archive" |
  sha256sum --check
cmp "$source_root/kernel.config" "$headers/.config"
mkdir -p "$build/kbuild" "$build/assets"
cp -a "$headers/." "$build/kbuild/"
tar -xzf "$archive" --strip-components=1 -C "$build/kbuild" --wildcards '*/drivers/gpu/drm/*'
cd "$build/kbuild"

for variant in 2 3 4; do
  source="$source_root/$variant"
  case "$variant" in
    2) patch=intel-xe-dsc-rc.patch ;;
    3) patch=beyond-fixed-dsc.patch ;;
    4) patch=beyond-non-desktop.patch ;;
  esac

  git apply --check "$source/$patch"
  git apply "$source/$patch"
  make -j"$(nproc)" M=drivers/gpu/drm/xe modules

  module="$build/xe-$variant.ko"
  objcopy --strip-debug drivers/gpu/drm/xe/xe.ko "$module"
  "$tool" -bb --define "_topdir $build/rpm-$variant" \
    --define "module_path $module" "$source/packaging/bsb-xe-dsc.spec"
  pkg="$build/rpm-$variant/RPMS/x86_64/bsb-xe-dsc-7.3.3-$variant.fc45.x86_64.rpm"
  rpm -K --nosignature "$pkg"
  install -m 0644 "$pkg" "$build/assets/${pkg##*/}"
done

cd "$build/assets"
sha256sum ./*.rpm > SHA256SUMS
printf 'RPMs and checksums are in %s\n' "$PWD"
